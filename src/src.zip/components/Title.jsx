import React from 'react';
import './CSS/Title.css';

const Title = () => {
  return (
    <h1 className="title">what's up Pals</h1>
  );
};

export default Title;
