import React from 'react';
import './CSS/Header.css';

const Header = () => {
  return (
    <div className="header">
      <img src="path_to_background_image" alt="Background" className="header-image" />
      <div className="header-content">
        <img src="path_to_profile_image" alt="Profile" className="profile-image" />
        <h1 className="profile-name">Gadiel Velarde</h1>
      </div>
    </div>
  );
};

export default Header;
